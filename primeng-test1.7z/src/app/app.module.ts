import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import { IndexComponent } from './index/index.component';
import { IndexService } from './index/index.service';

import { DataTableModule, SharedModule } from 'primeng/primeng';

@NgModule({
  declarations: [
    AppComponent, IndexComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,

    DataTableModule, SharedModule
  ],
  providers: [IndexService],
  bootstrap: [AppComponent]
})
export class AppModule { }
