import {
    Component, OnInit, ViewEncapsulation,
    HostBinding, HostListener, AfterViewInit,
    ElementRef, ViewChild, Renderer, AfterViewChecked 
} from '@angular/core';
import { IndexService } from './index.service';

@Component({
    selector: 'index',
    templateUrl: './index.template.html',
    styleUrls: ['./index.scss']
    //encapsulation: ViewEncapsulation.None
})
export class IndexComponent implements OnInit, AfterViewInit, AfterViewChecked  {

    followers = [];

    @HostBinding('style.height.px')
    height: number;

    @HostListener('window:resize', ['$event'])
    setHeight() {
        this.height = window.innerHeight;
        this.renderer.setElementStyle(
            this.elementRef.nativeElement.querySelector('.ui-datatable-scrollable-body'),
            'height', (window.innerHeight - 65) + 'px');
    }

    @ViewChild('selector') private someName;
    @ViewChild('myTable') private myTable;

    constructor(private service: IndexService, protected elementRef: ElementRef, private renderer: Renderer) {
        console.info(this.height);
    }

    ngOnInit() {
        this.service.getData()
            .subscribe(resp => {
                console.info(resp.json());
                this.followers = resp.json();
            }, err => {
                console.error(err.json());
            });
    }

    ngAfterViewInit() {
        setTimeout(() => {
            console.info(window.document.querySelector('.ui-datatable-scrollable-body'));
            console.info(this.someName.nativeElement.clientHeight);
            this.elementRef.nativeElement.querySelector('.ui-datatable-scrollable-body').style.height = (this.someName.nativeElement.clientHeight - 70) + 'px';
            //this.renderer.setElementStyle(this.elementRef.nativeElement.querySelector('.ui-datatable-scrollable-body'), 'height', (this.someName.nativeElement.clientHeight - 80) + 'px');
            //$('.ui-datatable-scrollable-body').style.height = (this.someName.nativeElement.clientHeight - 80) + 'px';
        }, 50);
    }

    ngAfterViewChecked() {
        console.info(22222222, this.someName.nativeElement.clientHeight);
    }

}